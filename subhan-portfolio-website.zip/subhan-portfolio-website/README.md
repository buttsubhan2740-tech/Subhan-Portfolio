# Subhan Butt — Portfolio (website files)

Ready-to-upload build of the 3D scroll portfolio. There's nothing to install: these files ARE the website.

## What's inside
| Path | What it is |
|---|---|
| `index.html` | The page (start screen, 3D journey, 2D version) |
| `assets/` | The site's code (`.js`) and styles (`.css`) |
| `fonts/` | 3D-letter font data + its open font licence (OFL) |
| `media/` | All videos: skill billboards (`skill-*`), best-work frames (`work-*`), start-button previews (`btn-*`), room showreel |
| `.nojekyll` | Tells GitHub Pages to serve every file as-is |

Links: 3D = the site address · 2D version = the address + `#flat`

## Upload to GitHub Pages (no terminal)
1. github.com → **New repository** → name it (e.g. `portfolio`) → **Public** → Create.
2. Click **uploading an existing file** and drag in everything from this folder (the files and folders, not the folder itself). **Commit changes**.
3. **Settings → Pages** → Source: **Deploy from a branch** → `main` / `(root)` → **Save**.
4. After 1–2 minutes the site is live at `https://YOUR-USERNAME.github.io/portfolio/`.

Note: the hidden `.nojekyll` file may not show in Finder. If it's missing, on GitHub click **Add file → Create new file**, name it `.nojekyll`, leave it empty and commit.

## Any other web host (Netlify, Vercel, cPanel, Hostinger…)
Upload the contents of this folder into the site's root folder (often `public_html`). No build step is needed.
Netlify: drag the whole folder onto app.netlify.com/drop.

## Updating later
The content is baked into `assets/index-*.js`. To change text or videos, edit the source project (`scroll-world/src/content.js`),
run `npm run build`, and upload the new `dist/` contents again (replace everything).
